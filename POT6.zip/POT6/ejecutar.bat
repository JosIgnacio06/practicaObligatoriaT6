@echo off
cd /d "%~dp0"
java -jar practicaObligatoriaT6.jar
pause